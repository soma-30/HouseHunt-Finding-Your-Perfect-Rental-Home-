const express = require("express");
const router = express.Router();

// Temporary dummy booking route

router.post("/", async (req, res) => {
  try {
    const { propertyId } = req.body;

    if (!propertyId) {
      return res.status(400).json({ message: "Property ID required" });
    }

    res.status(201).json({
      message: "Booking successful",
      propertyId,
    });
  } catch (error) {
    res.status(500).json({ message: "Booking failed" });
  }
});

module.exports = router;
