const express = require("express");
const router = express.Router();

/* ===========================
   DEMO PROPERTIES (6 Houses)
=========================== */

const properties = [
  {
    _id: "1",
    title: "Luxury 2BHK Apartment",
    location: "Hyderabad",
    price: 25000,
    image: "https://images.unsplash.com/photo-1560185007-cde436f6a4d0",
    ownerName: "Ramesh",
    phone: "919876543210",
    email: "ramesh@gmail.com",
    features: "2 Bedrooms, 2 Bathrooms, Balcony, Parking"
  },
  {
    _id: "2",
    title: "Modern Villa",
    location: "Bangalore",
    price: 55000,
    image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c",
    ownerName: "Suresh",
    phone: "919812345678",
    email: "suresh@gmail.com",
    features: "3BHK, Garden, Swimming Pool"
  },
  {
    _id: "3",
    title: "Cozy Studio",
    location: "Chennai",
    price: 12000,
    image: "https://images.unsplash.com/photo-1507089947368-19c1da9775ae",
    ownerName: "Anita",
    phone: "919900112233",
    email: "anita@gmail.com",
    features: "1 Room, Kitchen, Attached Bath"
  },
  {
    _id: "4",
    title: "Family Flat",
    location: "Vijayawada",
    price: 18000,
    image: "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d",
    ownerName: "Mahesh",
    phone: "919811223344",
    email: "mahesh@gmail.com",
    features: "2BHK, Lift, Parking"
  },
  {
    _id: "5",
    title: "Independent House",
    location: "Guntur",
    price: 22000,
    image: "https://images.unsplash.com/photo-1570129477492-45c003edd2be",
    ownerName: "Lakshmi",
    phone: "919844556677",
    email: "lakshmi@gmail.com",
    features: "2BHK, Garden, Terrace"
  },
  {
    _id: "6",
    title: "Premium Apartment",
    location: "Mumbai",
    price: 60000,
    image: "https://images.unsplash.com/photo-1600607688969-a5bfcd646154",
    ownerName: "Kiran",
    phone: "919877665544",
    email: "kiran@gmail.com",
    features: "3BHK, Gym, Security"
  }
];

/* GET ALL */
router.get("/", (req, res) => {
  res.json(properties);
});

/* GET BY ID */
router.get("/:id", (req, res) => {
  const property = properties.find(p => p._id === req.params.id);
  res.json(property);
});

/* NEARBY (Demo same data) */
router.get("/nearby/all", (req, res) => {
  res.json(properties);
});

module.exports = router;