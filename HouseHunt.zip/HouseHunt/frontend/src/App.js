import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import PropertyDetails from "./pages/PropertyDetails";

import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";

import OwnerDashboard from "./pages/owner/OwnerDashboard";
import RenterProfile from "./pages/renter/RenterProfile";

function App() {
  return (
    <Router>
      <Navbar />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/property/:id" element={<PropertyDetails />} />

        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        <Route path="/owner" element={<OwnerDashboard />} />
        <Route path="/profile" element={<RenterProfile />} />
      </Routes>
    </Router>
  );
}

export default App;