import React from "react";
import { Link, useNavigate } from "react-router-dom";

function Navbar() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));

  const logout = () => {
    localStorage.removeItem("user");
    navigate("/");
  };

  return (
    <div style={styles.nav}>
      <h2>HouseHunt</h2>

      <div>
        <Link to="/" style={styles.link}>Home</Link>

        {!user && (
          <>
            <Link to="/login" style={styles.link}>Login</Link>
            <Link to="/register" style={styles.link}>Register</Link>
          </>
        )}

        {user && user.role === "owner" && (
          <Link to="/owner" style={styles.link}>Dashboard</Link>
        )}

        {user && user.role === "renter" && (
          <Link to="/profile" style={styles.link}>Profile</Link>
        )}

        {user && (
          <button onClick={logout} style={styles.btn}>Logout</button>
        )}
      </div>
    </div>
  );
}

const styles = {
  nav: {
    display: "flex",
    justifyContent: "space-between",
    padding: "10px 20px",
    background: "#1e1e2f",
    color: "white"
  },
  link: {
    marginLeft: "15px",
    color: "white",
    textDecoration: "none"
  },
  btn: {
    marginLeft: "15px",
    cursor: "pointer"
  }
};

export default Navbar;