import { Card, CardContent, Typography, Button, Chip, Stack } from "@mui/material";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import BedIcon from "@mui/icons-material/Bed";
import AttachMoneyIcon from "@mui/icons-material/AttachMoney";
import { useNavigate } from "react-router-dom";

const PropertyCard = ({ property, onBook }) => {
  const navigate = useNavigate();

  const handleWhatsApp = () => {
    if (!property.ownerPhone) {
      alert("Owner phone number not available");
      return;
    }

    const message = `Hi, I am interested in your property: ${property.title}`;
    const whatsappURL = `https://wa.me/91${property.ownerPhone}?text=${encodeURIComponent(message)}`;

    window.open(whatsappURL, "_blank");
  };

  return (
    <Card
      className="card-custom"
      sx={{
        borderRadius: "18px",
        overflow: "hidden",
        transition: "0.4s",
        cursor: "pointer",
        "&:hover": {
          transform: "translateY(-8px)",
          boxShadow: "0px 20px 40px rgba(0,0,0,0.15)"
        }
      }}
    >
      {/* Image Section */}
      <div style={{ position: "relative" }}>
        <img
          src={property.image}
          alt={property.title}
          style={{
            width: "100%",
            height: "220px",
            objectFit: "cover"
          }}
        />

        <Chip
          icon={<AttachMoneyIcon />}
          label={`₹ ${property.price}`}
          sx={{
            position: "absolute",
            top: 15,
            right: 15,
            background: "linear-gradient(135deg, #2563EB, #1E40AF)",
            color: "white",
            fontWeight: "bold"
          }}
        />
      </div>

      {/* Content Section */}
      <CardContent>
        <Typography variant="h6" fontWeight="600" gutterBottom>
          {property.title}
        </Typography>

        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
          {property.description}
        </Typography>

        {/* Location */}
        <div className="d-flex align-items-center mb-2">
          <LocationOnIcon sx={{ color: "#2563EB", fontSize: 20 }} />
          <Typography variant="body2" sx={{ ml: 1 }}>
            {property.location}
          </Typography>
        </div>

        {/* Bedrooms */}
        <div className="d-flex align-items-center mb-3">
          <BedIcon sx={{ color: "#F59E0B", fontSize: 20 }} />
          <Typography variant="body2" sx={{ ml: 1 }}>
            {property.bedrooms} Bedrooms
          </Typography>
        </div>

        {/* Buttons Section */}
        <Stack spacing={1}>
          
          {/* Book Button */}
          <Button
            fullWidth
            onClick={() => onBook(property._id)}
            sx={{
              background: "linear-gradient(135deg, #2563EB, #1E40AF)",
              color: "white",
              fontWeight: "500",
              borderRadius: "10px",
              padding: "10px",
              "&:hover": {
                background: "linear-gradient(135deg, #1E40AF, #1E3A8A)"
              }
            }}
          >
            Book Now
          </Button>

          {/* View Details Button */}
          <Button
            fullWidth
            variant="outlined"
            onClick={() => navigate(`/property/${property._id}`)}
          >
            View Details
          </Button>

          {/* WhatsApp Button */}
          <Button
            fullWidth
            variant="contained"
            color="success"
            onClick={handleWhatsApp}
          >
            Contact on WhatsApp
          </Button>

        </Stack>
      </CardContent>
    </Card>
  );
};

export default PropertyCard;