const properties = [
  {
    id: 1,
    title: "Luxury Villa - Hyderabad",
    ownerName: "Ramesh Kumar",
    ownerPhone: "9876543210",
    ownerEmail: "ramesh@gmail.com",
    location: "Banjara Hills, Hyderabad",
    details: "3BHK Luxury Villa with Garden and Parking",
    images: [
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c",
      "https://images.unsplash.com/photo-1572120360610-d971b9d7767c",
      "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c",
      "https://images.unsplash.com/photo-1600566752355-35792bedcfea",
      "https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde"
    ]
  },
  {
    id: 2,
    title: "Modern House - Vijayawada",
    ownerName: "Suresh",
    ownerPhone: "9123456780",
    ownerEmail: "suresh@gmail.com",
    location: "Benz Circle, Vijayawada",
    details: "2BHK Modern Home",
    images: [
      "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf",
      "https://images.unsplash.com/photo-1570129477492-45c003edd2be",
      "https://images.unsplash.com/photo-1600585154205-4d6d0f4d5b2b",
      "https://images.unsplash.com/photo-1600607687644-c94bf1d83d57",
      "https://images.unsplash.com/photo-1568605114967-8130f3a36994"
    ]
  },
  {
    id: 3,
    title: "Beach House - Vizag",
    ownerName: "Mahesh",
    ownerPhone: "9988776655",
    ownerEmail: "mahesh@gmail.com",
    location: "RK Beach, Vizag",
    details: "Sea Facing Beach House",
    images: [
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511",
      "https://images.unsplash.com/photo-1605276373954-0c4a0dac5b12",
      "https://images.unsplash.com/photo-1600607687640-36a8e5d1ed2b",
      "https://images.unsplash.com/photo-1600607687618-49a5a6a1e8f5",
      "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3"
    ]
  },
  {
    id: 4,
    title: "City Apartment - Bangalore",
    ownerName: "Anil",
    ownerPhone: "9871234560",
    ownerEmail: "anil@gmail.com",
    location: "MG Road, Bangalore",
    details: "Luxury Apartment",
    images: [
      "https://images.unsplash.com/photo-1600607687087-4e6e1c5e3d8b",
      "https://images.unsplash.com/photo-1600607687644-c94bf1d83d57",
      "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c",
      "https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde",
      "https://images.unsplash.com/photo-1600566752355-35792bedcfea"
    ]
  },
  {
    id: 5,
    title: "Farm House - Guntur",
    ownerName: "Prakash",
    ownerPhone: "9012345678",
    ownerEmail: "prakash@gmail.com",
    location: "Near Amaravati",
    details: "Farm House with Garden",
    images: [
      "https://images.unsplash.com/photo-1580587771525-78b9dba3b914",
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c",
      "https://images.unsplash.com/photo-1600607687618-49a5a6a1e8f5",
      "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3",
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511"
    ]
  },
  {
    id: 6,
    title: "Independent House - Warangal",
    ownerName: "Kiran",
    ownerPhone: "9090909090",
    ownerEmail: "kiran@gmail.com",
    location: "Hanamkonda, Warangal",
    details: "3BHK Independent House",
    images: [
      "https://images.unsplash.com/photo-1568605114967-8130f3a36994",
      "https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde",
      "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c",
      "https://images.unsplash.com/photo-1600607687618-49a5a6a1e8f5",
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511"
    ]
  }
];

export default properties;