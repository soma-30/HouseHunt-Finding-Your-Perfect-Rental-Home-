import React, { useEffect, useState } from "react";
import PropertyCard from "../components/PropertyCard";
import api from "../services/api";
import { Container, Grid, Typography } from "@mui/material";

const Home = () => {
  const [properties, setProperties] = useState([]);

  useEffect(() => {
    fetchProperties();
  }, []);

  const fetchProperties = async () => {
    try {
      const res = await api.get("/properties");
      setProperties(res.data);
    } catch (error) {
      console.error("Error fetching properties:", error);
    }
  };

  const handleBooking = async (propertyId) => {
    try {
      await api.post("/bookings", { propertyId });
      alert("Property booked successfully ✅");
    } catch (error) {
      alert("Booking failed ❌");
    }
  };

  return (
    <Container sx={{ mt: 5 }}>
      <Typography variant="h4" fontWeight="bold" gutterBottom>
        Available Properties
      </Typography>

      <Grid container spacing={3}>
        {properties.map((property) => (
          <Grid item xs={12} sm={6} md={4} key={property._id}>
            <PropertyCard
              property={property}
              onBook={handleBooking}
            />
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default Home;