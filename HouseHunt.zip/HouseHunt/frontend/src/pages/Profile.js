import { useEffect, useState } from "react";

function Profile() {
  const role = localStorage.getItem("role");

  const [liked, setLiked] = useState([]);
  const [uploaded, setUploaded] = useState([]);

  useEffect(() => {
    setLiked(JSON.parse(localStorage.getItem("likedProperties")) || []);
    setUploaded(JSON.parse(localStorage.getItem("myProperties")) || []);
  }, []);

  return (
    <div style={{ padding: "30px" }}>
      <h2>My Profile</h2>

      <p><b>Name:</b> {localStorage.getItem("name")}</p>
      <p><b>Email:</b> {localStorage.getItem("userEmail")}</p>
      <p><b>City:</b> {localStorage.getItem("city")}</p>
      <p><b>Role:</b> {role}</p>

      <hr />

      {role === "renter" && (
        <>
          <h3>❤️ Liked Properties</h3>
          {liked.length === 0 && <p>No liked properties.</p>}
          {liked.map((p, i) => (
            <div key={i} style={styles.card}>
              <img src={p.image} width="250" />
              <p>{p.title}</p>
              <p>₹{p.rent}</p>
            </div>
          ))}
        </>
      )}

      {role === "owner" && (
        <>
          <h3>🏠 Uploaded Properties</h3>
          {uploaded.length === 0 && <p>No uploaded properties.</p>}
          {uploaded.map((p, i) => (
            <div key={i} style={styles.card}>
              <img src={p.image} width="250" />
              <p>{p.title}</p>
              <p>₹{p.rent}</p>
            </div>
          ))}
        </>
      )}
    </div>
  );
}

const styles = {
  card: {
    border: "1px solid #ddd",
    padding: "15px",
    marginBottom: "15px",
    borderRadius: "8px"
  }
};

export default Profile;