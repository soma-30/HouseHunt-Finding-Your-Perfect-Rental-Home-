import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";

function PropertyDetails() {
  const { id } = useParams();
  const [property, setProperty] = useState(null);

  useEffect(() => {
    axios.get(`http://localhost:5000/api/properties/${id}`)
      .then(res => setProperty(res.data));
  }, [id]);

  if (!property) return <p>Loading...</p>;

  return (
    <div style={{ padding: "20px" }}>
      <img src={property.image} alt={property.title}width="400" />

      <h2>{property.title}</h2>
      <p><b>Location:</b> {property.location}</p>
      <p><b>Features:</b> {property.features}</p>
      <p><b>Owner:</b> {property.ownerName}</p>
      <p><b>Phone:</b> {property.phone}</p>
      <p><b>Email:</b> {property.email}</p>

      <br />

      <a href={`https://wa.me/${property.phone}`} target="_blank" rel="noreferrer">
        <button className="btn-success">WhatsApp</button>
      </a>

      <a href={`mailto:${property.email}`}>
        <button className="btn-warning">Gmail</button>
      </a>
    </div>
  );
}

export default PropertyDetails;