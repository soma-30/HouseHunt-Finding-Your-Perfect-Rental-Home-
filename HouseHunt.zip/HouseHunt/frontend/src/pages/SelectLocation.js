import { useNavigate } from "react-router-dom";

function SelectLocation() {
  const navigate = useNavigate();

  const selectCity = (city) => {
    localStorage.setItem("city", city);
    navigate("/");
  };

  return (
    <div style={{ padding: "40px" }}>
      <h2>Select Your Location</h2>

      <button onClick={() => selectCity("Hyderabad")}>Hyderabad</button>
      <button onClick={() => selectCity("Bangalore")}>Bangalore</button>
      <button onClick={() => selectCity("Chennai")}>Chennai</button>
    </div>
  );
}

export default SelectLocation;