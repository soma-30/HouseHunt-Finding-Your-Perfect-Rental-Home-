function AdminHome() {
  return (
    <div className="container mt-4">
      <h2>Admin Dashboard</h2>
      <p>Manage Users & Properties</p>
    </div>
  );
}

export default AdminHome;