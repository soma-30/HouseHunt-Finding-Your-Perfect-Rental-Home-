import { useState } from "react";
import { useNavigate } from "react-router-dom";

function AddProperty() {
  const navigate = useNavigate();

  const [property, setProperty] = useState({
    title: "",
    city: "",
    rent: "",
    details: "",
    phone: "",
    image: ""
  });

  const handleChange = (e) => {
    setProperty({ ...property, [e.target.name]: e.target.value });
  };

  const handleImage = (e) => {
    const reader = new FileReader();
    reader.onload = () => {
      setProperty({ ...property, image: reader.result });
    };
    reader.readAsDataURL(e.target.files[0]);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const existing = JSON.parse(localStorage.getItem("myProperties")) || [];
    localStorage.setItem(
      "myProperties",
      JSON.stringify([...existing, property])
    );

    alert("Property Added Successfully 🏠");
    navigate("/my-properties");
  };

  return (
    <div style={{ padding: "40px" }}>
      <h2>Add Property</h2>

      <form onSubmit={handleSubmit}>
        <input name="title" placeholder="Title" onChange={handleChange} /><br /><br />
        <input name="city" placeholder="City" onChange={handleChange} /><br /><br />
        <input name="rent" placeholder="Rent" onChange={handleChange} /><br /><br />
        <input name="phone" placeholder="Phone Number" onChange={handleChange} /><br /><br />
        <textarea name="details" placeholder="Details" onChange={handleChange}></textarea><br /><br />
        <input type="file" accept="image/*" onChange={handleImage} /><br /><br />

        <button type="submit">Add Property</button>
      </form>
    </div>
  );
}

export default AddProperty;