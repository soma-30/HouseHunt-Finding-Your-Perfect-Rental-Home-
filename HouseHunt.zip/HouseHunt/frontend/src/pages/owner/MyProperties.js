import { useState, useEffect } from "react";

function MyProperties() {
  const [properties, setProperties] = useState([]);

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem("myProperties")) || [];
    setProperties(saved);
  }, []);

  const deleteProperty = (index) => {
    const updated = properties.filter((_, i) => i !== index);
    setProperties(updated);
    localStorage.setItem("myProperties", JSON.stringify(updated));
  };

  return (
    <div style={{ padding: "40px" }}>
      <h2>My Uploaded Properties</h2>

      {properties.length === 0 && <p>No properties added yet.</p>}

      {properties.map((property, index) => (
        <div key={index} style={{
          border: "1px solid #ccc",
          padding: "20px",
          marginBottom: "20px",
          borderRadius: "10px"
        }}>
          <h3>{property.title}</h3>
          {property.image && (
            <img src={property.image} width="300" />
          )}
          <p>City: {property.city}</p>
          <p>Rent: ₹{property.rent}</p>
          <p>Phone: {property.phone}</p>
          <p>{property.details}</p>

          <button onClick={() => deleteProperty(index)}>
            Delete
          </button>
        </div>
      ))}
    </div>
  );
}

export default MyProperties;