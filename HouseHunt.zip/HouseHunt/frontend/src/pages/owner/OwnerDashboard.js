import React, { useEffect, useState } from "react";
import axios from "axios";

function OwnerDashboard() {
  const [nearby, setNearby] = useState([]);
  const user = JSON.parse(localStorage.getItem("user"));

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(pos => {
        axios.get(`http://localhost:5000/api/properties/nearby?lat=${pos.coords.latitude}&lng=${pos.coords.longitude}`)
          .then(res => setNearby(res.data));
      });
    }
  }, []);

  return (
    <div style={{ padding: "20px" }}>
      <h2>My Properties</h2>

      <h2>Nearby Properties</h2>

      {nearby.map(p => (
        <div key={p._id}>
          <h4>{p.title}</h4>
        </div>
      ))}
    </div>
  );
}

export default OwnerDashboard;