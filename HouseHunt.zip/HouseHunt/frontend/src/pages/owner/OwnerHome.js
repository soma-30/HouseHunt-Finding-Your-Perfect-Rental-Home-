function OwnerHome() {
  return (
    <div className="container mt-4">
      <h2>Owner Dashboard</h2>
      <p>Add / Manage Your Properties</p>
    </div>
  );
}

export default OwnerHome;