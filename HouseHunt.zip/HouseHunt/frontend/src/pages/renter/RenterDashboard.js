import { useNavigate } from "react-router-dom";

function RenterDashboard() {
  const navigate = useNavigate();
  const userName = localStorage.getItem("name") || "Renter";

  return (
    <div style={styles.container}>
      <h2 style={styles.heading}>Welcome, {userName} 👋</h2>

      <div style={styles.cardContainer}>
        
        <div style={styles.card} onClick={() => navigate("/renter/home")}>
          <h3>🏠 Browse Properties</h3>
          <p>View available rental homes</p>
        </div>

        <div style={styles.card} onClick={() => navigate("/profile")}>
          <h3>👤 My Profile</h3>
          <p>View and edit your details</p>
        </div>

        <div style={styles.card} onClick={() => navigate("/near-me")}>
          <h3>📍 Near Me</h3>
          <p>Find homes near your location</p>
        </div>

      </div>
    </div>
  );
}

const styles = {
  container: {
    padding: "40px",
    textAlign: "center",
    background: "linear-gradient(to right, #e3f2fd, #ffffff)",
    minHeight: "100vh"
  },
  heading: {
    marginBottom: "40px"
  },
  cardContainer: {
    display: "flex",
    justifyContent: "center",
    gap: "30px",
    flexWrap: "wrap"
  },
  card: {
    width: "250px",
    padding: "30px",
    borderRadius: "15px",
    background: "white",
    boxShadow: "0 5px 15px rgba(0,0,0,0.1)",
    cursor: "pointer",
    transition: "0.3s"
  }
};

export default RenterDashboard;