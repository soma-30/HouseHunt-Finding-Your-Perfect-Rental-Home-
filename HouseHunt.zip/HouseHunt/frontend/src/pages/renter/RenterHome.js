import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function RenterHome() {
  const navigate = useNavigate();
  const userCity = localStorage.getItem("city");

  const [properties, setProperties] = useState([]);
  const [search, setSearch] = useState("");
  const [maxPrice, setMaxPrice] = useState("");

  useEffect(() => {
    fetch("http://localhost:5000/api/properties")
      .then((res) => res.json())
      .then((data) => setProperties(data))
      .catch((err) => console.log(err));
  }, []);

  const filteredProperties = properties.filter((property) => {
    const matchCity = userCity ? property.location === userCity : true;
    const matchSearch = property.title
      .toLowerCase()
      .includes(search.toLowerCase());
    const matchPrice = maxPrice ? property.price <= maxPrice : true;

    return matchCity && matchSearch && matchPrice;
  });

  const handleLike = (property) => {
    const liked =
      JSON.parse(localStorage.getItem("likedProperties")) || [];

    const alreadyLiked = liked.find((p) => p._id === property._id);

    if (alreadyLiked) {
      alert("Already Liked ❤️");
      return;
    }

    localStorage.setItem(
      "likedProperties",
      JSON.stringify([...liked, property])
    );

    alert("Property Liked ❤️");
  };

  return (
    <div style={{ padding: "30px" }}>
      <h2>
        {userCity
          ? `Properties Near ${userCity}`
          : "Available Properties"}
      </h2>

      {/* 🔍 Filters */}
      <div style={{ marginTop: "20px", marginBottom: "20px" }}>
        <input
          placeholder="Search by title"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{ marginRight: "10px", padding: "8px" }}
        />

        <input
          type="number"
          placeholder="Max Price"
          value={maxPrice}
          onChange={(e) => setMaxPrice(e.target.value)}
          style={{ padding: "8px" }}
        />
      </div>

      <div style={{ display: "flex", flexWrap: "wrap", gap: "20px" }}>
        {filteredProperties.map((property) => (
          <div
            key={property._id}
            style={{
              width: "300px",
              borderRadius: "10px",
              overflow: "hidden",
              boxShadow: "0 5px 15px rgba(0,0,0,0.1)",
              background: "white",
            }}
          >
            <img
              src={
                property.image ||
                "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2"
              }
              alt="house"
              style={{
                width: "100%",
                height: "200px",
                objectFit: "cover",
              }}
            />

            <div style={{ padding: "15px" }}>
              <h3>{property.title}</h3>
              <p><b>Location:</b> {property.location}</p>
              <p><b>Rent:</b> ₹{property.price}</p>

              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <button
                  onClick={() => navigate(`/property/${property._id}`)}
                  style={{
                    padding: "6px 10px",
                    background: "#1976d2",
                    color: "white",
                    border: "none",
                    borderRadius: "5px",
                    cursor: "pointer",
                  }}
                >
                  View Details
                </button>

                <button
                  onClick={() => handleLike(property)}
                  style={{
                    padding: "6px 10px",
                    background: "#ff4081",
                    color: "white",
                    border: "none",
                    borderRadius: "5px",
                    cursor: "pointer",
                  }}
                >
                  ❤️
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default RenterHome;