import React, { useEffect, useState } from "react";
import axios from "axios";

function RenterProfile() {
  const [liked, setLiked] = useState([]);
  const user = JSON.parse(localStorage.getItem("user"));

  useEffect(() => {
    if (user) {
      axios
        .get(`http://localhost:5000/api/properties/liked/${user._id}`)
        .then((res) => setLiked(res.data))
        .catch((err) => console.log(err));
    }
  }, [user]);

  return (
    <div style={{ padding: "20px" }}>
      <h2>My Liked Properties ❤️</h2>

      {liked.length === 0 && <p>No liked properties yet</p>}

      {liked.map((property) => (
        <div key={property._id} style={styles.card}>
          <h4>{property.title}</h4>
          <p>{property.location}</p>
          <p>₹ {property.price}</p>
        </div>
      ))}
    </div>
  );
}

const styles = {
  card: {
    border: "1px solid #ddd",
    padding: "10px",
    marginBottom: "10px",
    borderRadius: "6px",
  },
};

export default RenterProfile;